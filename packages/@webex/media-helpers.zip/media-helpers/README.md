# @webex/media-helpers

[![standard-readme compliant](https://img.shields.io/badge/readme%20style-standard-brightgreen.svg?style=flat-square)](https://github.com/RichardLitt/standard-readme)

> Media helpers

This is an internal Cisco Webex plugin. As such, it does not strictly adhere to semantic versioning. Use at your own risk. If you're not working on one of our first party clients, please look at our [developer api](https://developer.webex.com/) and stick to our public plugins.

- [@webex/media-helpers](#webexmedia-helpers)
  - [Install](#install)
  - [Usage](#usage)
  - [Maintainers](#maintainers)
  - [Contribute](#contribute)
  - [License](#license)

## Install

```bash
npm install --save @webex/media-helpers
```

## Usage

### Effects
There are two effects included in this package:

Virtual background (e.g., blur, image replacement, video replacement)
Noise reduction (e.g., background noise removal)

#### Virtual background
The virtual background effect provides a virtual background for video calling. The virtual background may be an image, an mp4 video, or the user's background with blur applied.

**Applying the effect**
Supply a video stream to the effect and when loaded, it will return a new stream with the effect applied.

```javascript
import {LocalCameraTrack, VirtualBackgroundEffect} from '@webex/media-helpers';

// Create a new video stream by a getting user's video media.
const stream = await navigator.mediaDevices.getUserMedia({ video: { width, height } });

const videoTrackFromLocalStream = stream.getVideoTracks()[0];

const cameraTrack = new LocalCameraTrack(new MediaStream([videoTrackFromLocalStream]));

// Create the effect.
const effect = new VirtualBackgroundEffect({
  authToken: '<encoded-string>',
  mode: `BLUR`,
  blurStrength: `STRONG`,
  quality: `LOW`,
});

// add the effect on the input camera track.
await cameraTrack.addEffect("background-blur", effect);

//enable the effect once it is added to the track
await effect.enable()
```

#### Noise reduction
The noise reduction effect removes background noise from an audio stream to provide clear audio for calling.

**Applying the effect**
Supply an audio track or stream to the effect, the effect will handle updating the stream on enable/disable. In the case of a track being passed, listen to the 'track-updated' event to receive the updated track on enable/disable.

```javascript
import {LocalMicrophoneTrack, NoiseReductionEffect} from '@webex/media-helpers';

// Create a new audio stream by getting a user's audio media.
const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

const audioTrackFromLocalStream = stream.getVideoTracks()[0];

const microphoneTrack = new LocalMicrophoneTrack(new MediaStream([audioTrackFromLocalStream]));

// Create the effect.
const effect = new NoiseReductionEffect({
  authToken: '<encoded-string>',
  workletProcessorUrl: 'https://my-worklet-processor-url', // For 'WORKLET' mode
  legacyProcessorUrl: 'https://my-legacy-processor-url', // For 'LEGACY' mode
  mode: 'WORKLET', // or 'LEGACY'
});

// add the effect on microphone track.
await microphoneTrack.addEffect("background-noise-removal", effect);

//enable the effect once it is added to the track
await effect.enable()
```

## Maintainers

This package is maintained by [Cisco Webex for Developers](https://developer.webex.com/).

## Contribute

Pull requests welcome. Please see [CONTRIBUTING.md](https://github.com/webex/webex-js-sdk/blob/master/CONTRIBUTING.md) for more details.

## License

© 2016-2022 Cisco and/or its affiliates. All Rights Reserved.
